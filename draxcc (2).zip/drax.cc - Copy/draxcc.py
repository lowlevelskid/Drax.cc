import time
import os
import sys
import requests
import json
from datetime import datetime
from pystyle import Colorate, Colors, Center

# Function to clear the screen
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# ASCII art
ascii_art = '''
                                          ▄▄▄▄  ▄▄▄   ▄▄▄· ▐▄• ▄     ▄▄·  ▄▄· 
                                         ██▪ ██ ▀▄ █·▐█ ▀█  █▌█▌▪   ▐█ ▌▪▐█ ▌▪
                                         ██· ▐█▌▐▀▀▄ ▄█▀▀█  ·██·    ██ ▄▄██ ▄▄
                                         ██. ██ ▐█•█▌▐█ ▪▐▌▪▐█·█▌   ▐███▌▐███▌
                                         ▀▀▀▀▀• .▀  ▀ ▀  ▀ •▀▀ ▀▀ ▀ ·▀▀▀ ·▀▀▀ 
'''

# Function to show the loading screen
def loading_screen():
    colored_ascii = Colorate.Horizontal(Colors.blue_to_green, ascii_art)

    for i in range(1, 8):
        clear_screen()
        print(colored_ascii)
        print(f'                                           >> [Connecting to Servers :{i}:] <<')
        time.sleep(1)  # Sleep for 1 second

    # Fade out effect
    for fade in range(10, -1, -1):
        clear_screen()
        fade_color = Colorate.Vertical(Colors.red_to_yellow, ascii_art)
        print(fade_color) if fade % 2 == 0 else print(ascii_art)
        time.sleep(0.5)

    clear_screen()  # Clear screen before the main content appears

# Function to display the gradient text logo
def gradient_text():
    logo = """
            ▄▄▄▄  ▄▄▄   ▄▄▄· ▐▄• ▄     ▄▄·  ▄▄· 
           ██▪ ██ ▀▄ █·▐█ ▀█  █▌█▌▪   ▐█ ▌▪▐█ ▌▪
           ▐█· ▐█▌▐▀▀▄ ▄█▀▀█  ·██·    ██ ▄▄██ ▄▄
           ██. ██ ▐█•█▌▐█ ▪▐▌▪▐█·█▌   ▐███▌▐███▌
           ▀▀▀▀▀• .▀  ▀ ▀  ▀ •▀▀ ▀▀ ▀ ·▀▀▀ ·▀▀▀ 
          >> [Webhook Multitool developed by @flcu]<<
              Discord:https://discord.gg/2bbVbj356p
                    YT:@lowlevelskid
                Github:@lowlevelskid
    ======================================================= 
                       Choose an Option
    ======================================================= 
    """
    print(Colorate.Horizontal(Colors.cyan_to_blue, Center.XCenter(logo), 1))

# Function to create gradient text options
def gradient_option(text):
    return Colorate.Horizontal(Colors.cyan_to_blue, Center.XCenter(text))

# Function to create gradient prompt
def gradient_prompt(username):
    return Colorate.Horizontal(Colors.cyan_to_blue, Center.XCenter(f"[<root={username}]"))

# Function to display the menu
def display_menu():
    gradient_text()
    print(gradient_option("1. Send Webhook with Markdown"))
    print(gradient_option("2. Delete Webhook"))
    print(gradient_option("3. Log Webhook Activity"))
    print(gradient_option("4. View Webhook Info"))
    print(gradient_option("5. Change Webhook Avatar"))
    print(gradient_option("6. Send Customized Embedded Message"))
    print(gradient_option("7. Spam Messages"))
    print(gradient_option("8. Upload File"))
    print(gradient_option("9. Clone Webhook"))
    print(gradient_option("10. Manage Dual Webhook"))
    print(gradient_option("11. Close the Script"))
    print("")

def login():
    clear_screen()
    print(gradient_option("== Login To Ur Webhook =="))
    print(gradient_option("Socials:"))
    print(gradient_option("Discord:https://discord.gg/2bbVbj356p"))
    print(gradient_option("YT:@lowlevelskid"))
    print(gradient_option("Github:@lowlevelskid"))
    webhook_url = input("[<url>] ")
    clear_screen()  # Clear the login screen after input
    return [webhook_url]  # Start with one webhook

def manage_dual_webhook(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Manage Dual Webhook =="))
    action = input("Would you like to (1) Add or (2) Remove the dual webhook? (Enter 1 or 2): ")
    if action == '1':
        dual_webhook_url = input("Enter the dual webhook URL: ")
        webhook_urls.append(dual_webhook_url)
        print(f"Dual webhook added: {dual_webhook_url}")
        log_activity("manage_dual_webhook", dual_webhook_url, action="added")
    elif action == '2':
        if len(webhook_urls) > 1:
            print("Current Dual Webhook: ", webhook_urls[1])
            confirm = input("Are you sure you want to remove the dual webhook? (y/n): ").lower()
            if confirm in ['y', 'yes']:
                removed_webhook = webhook_urls.pop(1)
                print(f"Dual webhook removed: {removed_webhook}")
                log_activity("manage_dual_webhook", removed_webhook, action="removed")
            else:
                print("No changes made.")
        else:
            print("No dual webhook to remove.")
    else:
        print("Invalid option.")
    input("Press Enter to return to the main menu.")

def log_activity(action, url, content=None, status=None, extra=None):
    """Log webhook activity to a file."""
    with open("webhook_activity_log.txt", "a") as log_file:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_file.write(f"[{timestamp}] Action: {action}, URL: {url}")
        if content:
            log_file.write(f", Content: {content}")
        if status:
            log_file.write(f", Status: {status}")
        if extra:
            log_file.write(f", Extra: {extra}")
        log_file.write("\n")

def send_webhook(url, content):
    data = {
        "content": content
    }
    response = requests.post(url, json=data)
    if response.status_code == 204:
        print("Message sent successfully.")
        log_activity("send", url, content, "success")
    else:
        print(f"Failed to send message: {response.status_code}")
        log_activity("send", url, content, f"failed: {response.status_code}")

def send_webhook_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Send Webhook with Markdown =="))
    content = input("Enter the message to send (Markdown supported): ")
    for url in webhook_urls:
        send_webhook(url, content)
    input("\nPress Enter to return to the main menu.")

def delete_webhook(url):
    response = requests.delete(url)
    if response.status_code == 204:
        print(f"Webhook deleted successfully: {url}")
        log_activity("delete", url)
    else:
        print(f"Failed to delete webhook: {response.status_code}")
        log_activity("delete", url, status=f"failed: {response.status_code}")

def delete_webhook_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Delete Webhook =="))
    for url in webhook_urls:
        delete_webhook(url)
    input("\nPress Enter to return to the main menu.")

def log_webhook_activity(url):
    # Placeholder for logging webhook activity
    print(f"Logging activity for: {url}")

def log_webhook_activity_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Log Webhook Activity =="))
    for url in webhook_urls:
        log_webhook_activity(url)
    input("\nPress Enter to return to the main menu.")

def view_webhook_info(url):
    response = requests.get(url)
    if response.status_code == 200:
        webhook_info = response.json()
        print(f"Webhook Info for {url}:")
        print(json.dumps(webhook_info, indent=2))
    else:
        print(f"Failed to retrieve info: {response.status_code}")

def view_webhook_info_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== View Webhook Info =="))
    for url in webhook_urls:
        view_webhook_info(url)
    input("\nPress Enter to return to the main menu.")

def change_webhook_avatar(url):
    # Placeholder for changing webhook avatar
    print(f"Changing avatar for {url}")

def change_webhook_avatar_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Change Webhook Avatar =="))
    for url in webhook_urls:
        change_webhook_avatar(url)
    input("\nPress Enter to return to the main menu.")

def send_embedded_message(url):
    # Placeholder for sending customized embedded messages
    print(f"Sending embedded message to {url}")

def send_embedded_message_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Send Customized Embedded Message =="))
    for url in webhook_urls:
        send_embedded_message(url)
    input("\nPress Enter to return to the main menu.")

def upload_file(url):
    # Placeholder for file upload functionality
    print(f"Uploading file to {url}")

def upload_file_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Upload File =="))
    for url in webhook_urls:
        upload_file(url)
    input("\nPress Enter to return to the main menu.")

def clone_webhook(url):
    # Placeholder for cloning webhook functionality
    print(f"Cloning webhook {url}")

def clone_webhook_menu(webhook_urls):
    clear_screen()
    print(gradient_option("\n== Clone Webhook =="))
    for url in webhook_urls:
        clone_webhook(url)
    input("\nPress Enter to return to the main menu.")

def spam_messages(webhook_urls):
    message = input("Enter the message to spam: ")
    count = int(input("Enter the number of times to spam: "))
    delay = float(input("Enter the delay between messages (in seconds, e.g., 0.5): "))  # Allow for decimal input
    for url in webhook_urls:
        for _ in range(count):
            send_webhook(url, message)
            time.sleep(delay)  # Use the custom delay
    input("Spamming complete. Press Enter to return to the main menu.")

def main():
    loading_screen()
    username = input("Enter your username: ")
    webhook_urls = login()

    while True:
        display_menu()
        choice = input(gradient_prompt(username))
        clear_screen()

        if choice == '1':
            send_webhook_menu(webhook_urls)
        elif choice == '2':
            delete_webhook_menu(webhook_urls)
        elif choice == '3':
            log_webhook_activity_menu(webhook_urls)
        elif choice == '4':
            view_webhook_info_menu(webhook_urls)
        elif choice == '5':
            change_webhook_avatar_menu(webhook_urls)
        elif choice == '6':
            send_embedded_message_menu(webhook_urls)
        elif choice == '7':
            spam_messages(webhook_urls)
        elif choice == '8':
            upload_file_menu(webhook_urls)
        elif choice == '9':
            clone_webhook_menu(webhook_urls)
        elif choice == '10':
            manage_dual_webhook(webhook_urls)
        elif choice == '11':
            print("Exiting the script...")
            sys.exit()
        else:
            print("Invalid option, please try again.")

if __name__ == "__main__":
    main()
